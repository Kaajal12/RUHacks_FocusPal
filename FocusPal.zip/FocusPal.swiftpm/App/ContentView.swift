import SwiftUI
import AVFoundation
import  UserNotifications

struct ContentView: View {
    @EnvironmentObject var appModel: AppModel
    
    var body: some View {
        NavigationView {
            TabView {
                HomeView()
                    .tabItem {
                        Image(systemName: "house")
                        Text("Home")
                    }
                FocusPalView()
                    .tabItem {
                        Image(systemName: "hourglass")
                        Text("Focus")
                    }
                
                ExploreView()
                    .tabItem {
                        Image(systemName: "magnifyingglass")
                        Text("Explore")
                    }
                
                MLGameView()
                    .tabItem {
                        Image(systemName: "gamecontroller.fill")
                        Text("Game")
                    }
            }
        }
        .accentColor(.blue)
    }
}

struct HomeView : View {
    var body: some View {
//        Text("FocusPal\nEmpowering focus.")
//        
//            .font(.system(size: 40))
//            .foregroundColor(.blue) 
//            .bold()
////            .padding(.top, 50)

        Image("Logo1")
            .resizable()  
            .scaledToFit()  
            .frame(width: 500, height: 500)
        
        
        
    }
}

struct FocusPalView: View {
    @State private var isTaskInProgress = false
    @State private var seconds = 0
    @State private var focusTime = 1 * 60 // Default focus time: 1 minute (60 seconds)
    @State private var breakTime = 30 // Break time: 30 seconds
    @State private var taskName = ""
    @State private var isOnBreak = false
    @State private var timer: Timer? // Use @State to manage the timer
    @State private var audioPlayer: AVAudioPlayer? // AVAudioPlayer to play sound
    @State private var selectedFocusTimeIndex = 0 // To keep track of selected focus time
    @State private var isTaskSet = false // New state to track if the task has been set

    
    let focusTimeOptions = [1, 5, 15, 25] // Focus time options in minutes
    
    var timeDisplay: String {
        let minutes = seconds / 60
        let secondsLeft = seconds % 60
        return String(format: "%02d:%02d", minutes, secondsLeft)
    }
    
    var body: some View {
        VStack {
            Text("Enter Task:")
                .font(.largeTitle)
                .bold()
                .padding(.top, 50)
                .padding()
            TextField("Complete mini-project.", text: $taskName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .font(.title2)
            
            Button(action: {
                setTask()
            }) {
                Text("Set Task")
                    .font(.title2)
                    .frame(width: 250, height: 50)
                    .foregroundColor(.white)
                    .background(Color.green)
                    .cornerRadius(10)
                    .padding()
            }
            if isTaskSet {
                Text("Task is: \(taskName)")
                    .font(.title2)
                    .padding()
                    .bold()
            }
          

            
            Text(isOnBreak ? "Break Time!" : "Focus Time")
                .font(.title2)
                .padding()
            
            Text(timeDisplay)
                .font(.system(size: 48))
                .bold()
                .padding(.top, 10)
            
            // Spacer moved lower, bringing Picker and Button higher up
            VStack(spacing: 20) {
                // Focus Time Picker
                Picker("Select Focus Time", selection: $selectedFocusTimeIndex) {
                    ForEach(0..<focusTimeOptions.count, id: \.self) { index in
                        Text("\(focusTimeOptions[index]) minutes").tag(index)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .onChange(of: selectedFocusTimeIndex) { newValue in
                    focusTime = focusTimeOptions[selectedFocusTimeIndex] * 60 // Update focus time in seconds
                }
                
                Button(action: {
                    toggleTask()
                }) {
                    Text(isTaskInProgress ? "Pause Task" : "Start Task")
                        .font(.title2)
                        .frame(width: 250, height: 50)
                        .foregroundColor(.white)
                        .background(isTaskInProgress ? Color.red : Color.blue)
                        .cornerRadius(10)
                        .padding()
                }
            }
            .padding()
            
            Spacer() // The spacer now goes at the bottom, ensuring these elements are above
        }
        .onAppear {
            requestNotificationPermission()
        }
        .padding()
    }
    
    func toggleTask() {
        if !isTaskInProgress {
            isTaskInProgress = true
            startTimer()
            sendReminder()
        } else {
            isTaskInProgress = false
            stopTimer()
        }
    }
    func setTask() {
        isTaskSet = true // Mark task as set
    }
    
    func startTimer() {
        let timeInterval = isOnBreak ? TimeInterval(breakTime) : TimeInterval(focusTime)
        
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            seconds += 1
            
            if !isOnBreak && seconds >= focusTime {
                seconds = 0
                isOnBreak = true
                playBreakSound() // Play sound when switching to break time
                sendBreakReminder()
            } else if isOnBreak && seconds >= breakTime {
                seconds = 0
                isOnBreak = false
                playFocusSound() // Play sound when switching back to focus time
            }
        }
    }
    
    func stopTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { granted, error in
            if granted {
                print("Notification permission granted.")
            } else {
                print("Notification permission denied.")
            }
        }
    }
    
    func sendReminder() {
        let content = UNMutableNotificationContent()
        content.title = "Procrastination Alert"
        content.body = "You're getting distracted! Focus on the task: \(taskName). Try writing 1 sentence to start."
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 15 * 60, repeats: false)
        let request = UNNotificationRequest(identifier: "taskReminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    
    func sendBreakReminder() {
        let content = UNMutableNotificationContent()
        content.title = "Break Time!"
        content.body = "You've worked for \(focusTime / 60) minute(s)! Time for a 30-second break."
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 30, repeats: false)
        let request = UNNotificationRequest(identifier: "breakReminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    
    func playBreakSound() {
        guard let url = Bundle.main.url(forResource: "/Dataset/ringtone", withExtension: "mp3") else {
            print("Sound file not found.")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
            
            // Stop the sound after 5 seconds
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                self.audioPlayer?.stop()
            }
            
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
    // Play sound after focus time ends and before the next break
    func playFocusSound() {
        // Ensure the resource is in the correct path within the Resources folder
        if let url = Bundle.main.url(forResource: "ringtone", withExtension: "mp3") {
            print("Sound file found at: \(url)")
            do {
                let audioPlayer = try AVAudioPlayer(contentsOf: url)
                audioPlayer.play()
            } catch {
                print("Error playing sound: \(error.localizedDescription)")
            }
        } else {
            print("Sound file not found.")
        }
    

    }
}



struct ExploreView: View {
    @State private var selectedTipIndex = 0
    @State private var selectedAnswer = ""
    @State private var quizResult = ""
    
    // Tips for the carousel
    let tips = [
        "Break big tasks into smaller, manageable parts.",
        "Set a timer to work in short, focused intervals.",
        "Remove distractions by putting your phone on silent.",
        "Take breaks regularly to recharge and stay productive."
    ]
    
    let procrastinationQuiz = [
        ("I am overwhelmed by the task", "Try breaking your task into smaller pieces to make it more manageable!"),
        ("I am easily distracted", "Remove all distractions, such as turning off your phone or using website blockers."),
        ("I struggle to stay motivated", "Set clear goals and reward yourself for completing tasks to stay motivated.")
    ]
    
    var body: some View {
        VStack {
            // Title
            Text("Explore Tips for Productivity")
                .font(.title)
                .fontWeight(.bold)
                .padding()
            
            // Tips Navigation
            HStack {
                Button(action: {
                    if selectedTipIndex > 0 {
                        selectedTipIndex -= 1
                    }
                }) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(.blue)
                        .padding()
                }
                
               
                Text(tips[selectedTipIndex])
                    .font(.title)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(15)
                    .padding()
                
                Button(action: {
                    if selectedTipIndex < tips.count - 1 {
                        selectedTipIndex += 1
                    }
                }) {
                    Image(systemName: "arrow.right.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(.blue)
                        .padding()
                }
            }
            
            Divider().padding()
            
            Text("What Causes Your Procrastination?")
                .bold()
                .font(.title)
                .padding()
            
            VStack {
                ForEach(0..<procrastinationQuiz.count, id: \.self) { index in
                    Button(action: {
                        selectedAnswer = procrastinationQuiz[index].0
                        quizResult = procrastinationQuiz[index].1
                    }) {
                        Text(procrastinationQuiz[index].0)
                            .font(.title2)
                            .padding()
                            .background(Color.green.opacity(0.1))
                            .cornerRadius(10)
                            .foregroundColor(.black)
                    }
                    .padding(.vertical, 5)
                }
            }
            
            if !quizResult.isEmpty {
                Text("Procrastination Tip: \(quizResult)")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.black)
                    .padding()
            }
        }
        .padding()
    }
}




struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(AppModel()) 
    }
}

